// main.js

const accessToken = 'IGQWRORE92MWNnbWR2TDk0dmlaTDRtc3ZAMWHdIZAzlKcHdBRUFTeVREcGlmWER3anBxa2FHOTNFcjh3NnZAkQ1BkMTRhQVhJTVNOaTRjSnYyN2NucUJkTFJZASHN1dEs2Mm9scTh5b3hhT3pPNWZAWSi1kTmktS0k4bTQZD';

function fetchImagesFromUsername(username) {
    fetch(`https://graph.instagram.com/v12.0/${username}/media?fields=id,caption,media_type,media_url,permalink&access_token=${accessToken}`)
    .then(response => {
        if (!response.ok) {
            throw new Error('Không thể tìm thấy người dùng.');
        }
        return response.json();
    })
    .then(data => {
        if (data.data && data.data.length > 0) {
            data.data.forEach(item => {
                const imageUrl = item.media_url;
                downloadImage(imageUrl);
            });
        } else {
            throw new Error('Không có ảnh nào được tìm thấy.');
        }
    })
    .catch(error => {
        console.error('Lỗi:', error.message);
    });
}

function downloadImage(imageUrl) {
    // Thực hiện logic tải ảnh ở đây
    console.log('Đang tải ảnh:', imageUrl);
}
